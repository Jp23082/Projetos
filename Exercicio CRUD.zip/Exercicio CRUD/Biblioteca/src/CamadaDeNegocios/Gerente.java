package CamadaDeNegocios;

public class Gerente extends Funcionario {
	
}
