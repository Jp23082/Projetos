package CamadaDeNegocios;

import java.util.Scanner;

import DAO.ClienteDAO;
import DAO.ProdutoDAO;
import VO.ClienteVO;
import VO.ProdutoVO;

public class Funcionario {
	private String nome;
	private int id,idade;
	Scanner entrada = new Scanner(System.in);
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getIdade() {
		return idade;
	}
	public void setIdade(int idade) {
		this.idade = idade;
	}

	public void Cadastra_Produto() {
		
		ProdutoVO pr = new ProdutoVO();
		ProdutoDAO pro = new ProdutoDAO(); 
		System.out.print("\nID: ");
		pr.setId(entrada.nextInt());
		System.out.print("Produto: ");
		pr.setNome_produto(entrada.next());
		pro.Cadastrar(pr);
		entrada.close();
	}
	
	public void Cadastra_Pedido() {
		//Metodo...
	}
	
	public void Cadastra_Cliente() {
		ClienteVO cl = new ClienteVO();
		ClienteDAO cli = new ClienteDAO(); 
		System.out.print("ID: ");
		cl.setId(entrada.nextInt());
		System.out.print("Nome Cliente: ");
		cl.setNome(entrada.next());
		cli.Cadastrar(cl);
		entrada.close();
	}

}
