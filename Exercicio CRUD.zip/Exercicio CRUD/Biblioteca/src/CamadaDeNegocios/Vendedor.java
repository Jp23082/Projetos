package CamadaDeNegocios;

public class Vendedor extends Funcionario{


}
