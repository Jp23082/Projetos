package CamadaDeNegocios;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.Scanner;

import DAO.ClienteDAO;
import DAO.ProdutoDAO;
import VO.ClienteVO;
import VO.ProdutoVO;

public class Menu {
	
	
	public static void Menu_Inicio(){
		Scanner teclado = new Scanner(System.in);
		System.out.print("=====BEM VINDO=====\n1-Login\n2-Novo Cadastro\n3-Consultar\n4-Sair\n\nOp��o: ");
		int opcao = teclado.nextInt();
		
		switch (opcao) {
		case 1:
			Tela_Login();
			break;
		case 2:
			Tela_Cadastro();
			break;
		case 3:
			Consulta();
			break;
		case 4:
			System.out.println("\nSISTEMA FINALIZADO!!!");
			System.exit(0);
			break;

		default:
			break;
		}
		
		teclado.close();
		
	}
	
	public static void Tela_Login(){
		try {
			Scanner teclado = new Scanner(System.in);
			System.out.println("\n=====LOGIN=====");
			System.out.print("Usu�rio: ");
			String login = teclado.nextLine();
			
			Scanner ler = new Scanner(new FileInputStream("Cadastro.txt"));
			
			while(ler.hasNextLine()) {
				String linha = ler.nextLine();
				String array[] = linha.split("\\|");
				String nome = (String)array[1];
				if(nome.equals(login)) {
					ler.close();
					System.out.println("\n\nBEM VINDO "+ login.toUpperCase() +"\n\n");
					if(array[0].equals("G"))
						Tela_Principal_Gerente();
					else if(array[0].equals("V"))
						Tela_Principal_Vendedor();

					break;
				}
			}
			teclado.close();
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	public static void Tela_Cadastro() {
		try {
			Scanner teclado = new Scanner(System.in);
			
			System.out.print("\n======CADASTRO FUNCION�RIO=====\n1- Gerente\n2- Vendedor\n\nOp��o: ");
			int opcao = teclado.nextInt();

			switch (opcao) {
			case 1:
				System.out.print("\n\n======CADASTRO GERENTE======\nID Gerente: ");
				Gerente ge = new Gerente();
				ge.setId(teclado.nextInt());
				PrintStream escrever  = new PrintStream(new FileOutputStream("Cadastro.txt",true));
				String msg = "G|" + ge.getNome();
				escrever.println(msg);				
				System.out.println("\nCADASTRO REALIZADO COM SUCESSO\n");
				
				escrever.close();
				teclado.close();
				
				Menu_Inicio();
				break;
			case 2:
				System.out.print("\n\n======CADASTRO VENDEDOR======\nID Vendedor: ");
				Vendedor ve = new Vendedor();
				ve.setId(teclado.nextInt());
				System.out.print("Nome: ");
				ve.setNome(teclado.next());
				System.out.print("Idade: ");
				ve.setIdade(teclado.nextInt());
				PrintStream vendedor  = new PrintStream(new FileOutputStream("Cadastro.txt",true));
				String msn = "V|" + ve.getId()+"|"+ve.getNome()+"|"+ve.getIdade()+" Anos";
				vendedor.println(msn);				
				System.out.println("\nCADASTRO REALIZADO COM SUCESSO\n");
				Menu_Inicio();
				break;
			default:
				System.out.println("Op��o Invalida");
				break;
			}
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
		
	}
	
	public static void Tela_Principal_Gerente() {
		Scanner entrada = new Scanner(System.in);
		Gerente ge = new Gerente();
		System.out.print("===== TELA PRINCIPAL - GERENTE (CADASTRO) =====\n1- Produtos\n2- Clientes\n3-Funcion�rio\n\nOp��o: ");
		int opcao = entrada.nextInt();
		switch (opcao) {
		case 1:
			ge.Cadastra_Produto();
			Tela_Principal_Gerente();
			break;
		case 2:
			ge.Cadastra_Cliente();
			Tela_Principal_Gerente();
			break;
		default:
			System.out.println("OP��O INV�LIDA");
			break;
		}		
		entrada.close();
	}
	
	public static void Tela_Principal_Vendedor() {
		System.out.print("===== TELA PRINCIPAL - VENDEDOR (CADASTRO) =====\n1- Produtos\n2- Clientes\n\nOp��o: ");
		Scanner entrada = new Scanner(System.in);
		Vendedor ve = new Vendedor();
		
		int opcao = Integer.parseInt(entrada.next());
		switch (opcao) {
		case 1:
			ve.Cadastra_Produto();
			Tela_Principal_Vendedor();
			break;
		case 2:
			ve.Cadastra_Cliente();
			Tela_Principal_Vendedor();
			break;
		default:
			System.out.println("OP��O INV�LIDA");
			break;
		}		
		entrada.close();
	}
	
	public static void Consulta() {
		Scanner teclado = new Scanner(System.in);
		try {
			System.out.print("\n=====CONSULTA=====\n1-Produto\n2-Cliente\n3-Pedidos\n\nOp��o: ");
			int opcao = teclado.nextInt();
			switch (opcao) {
			case 1:
				System.out.println("\n=====PRODUTOS CADASTRADOS=====");
				Scanner produtos = new Scanner(new FileInputStream("Produto.txt"));
				while(produtos.hasNextLine()) {
					String linha = produtos.nextLine();
					System.out.println("- " + linha);
					
				}
				
				produtos.close();	
				Menu_Inicio();
				
				break;
			case 2:
				System.out.println("\n=====CLIENTES CADASTRADOS=====");
				Scanner clientes = new Scanner(new FileInputStream("Clientes.txt"));
				while(clientes.hasNextLine()) {
					String linha = clientes.nextLine();
					System.out.println("- " + linha);
				}
				
				clientes.close();
				Menu_Inicio();
				
				break;
			default:
				break;
			}
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
		finally {
			teclado.close();
		}
	}
	

}

