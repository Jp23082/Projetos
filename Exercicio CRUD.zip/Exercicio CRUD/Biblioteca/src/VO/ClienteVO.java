package VO;

public class ClienteVO extends PadraoVO {
	//Atributos
	private String nome;

	public String getNome() {
		return nome;
	}
	public void setNome(String Nome) {
		this.nome = Nome;
	}
	
	
	
	
	
}
