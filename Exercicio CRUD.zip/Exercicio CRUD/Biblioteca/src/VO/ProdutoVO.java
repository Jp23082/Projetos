package VO;

public class ProdutoVO extends PadraoVO{
	private String nome_produto;

	public String getNome_produto() {
		return nome_produto;
	}

	public void setNome_produto(String Nome_produto) {
		this.nome_produto = Nome_produto;
	}
}
