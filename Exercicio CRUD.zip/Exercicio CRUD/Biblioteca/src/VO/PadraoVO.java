package VO;

public class PadraoVO {
	// Atributos
	private int id;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
}
