package VO;

public class PedidoVO extends PadraoVO {
	//Atributos 
	
}
