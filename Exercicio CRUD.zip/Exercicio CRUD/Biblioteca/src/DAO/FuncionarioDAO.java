package DAO;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;

import VO.FuncionarioVO;
import VO.PadraoVO;

public class FuncionarioDAO extends PadraoDAO {

		@Override
		public void Cadastrar(PadraoVO pdr) {
			try {
				FuncionarioVO funcionario = (FuncionarioVO)pdr;
				PrintStream escrever = new PrintStream(new FileOutputStream("Cadastro.txt",true));
				String cadastro = "F|"+ funcionario.getId()+"|"+ funcionario.getNome();
				escrever.println(cadastro);
				escrever.close();
			}
			catch(FileNotFoundException e ) {
				System.out.println(e.getMessage());
			}
		}
}
