package DAO;

import java.io.FileOutputStream;
import java.io.PrintStream;
import VO.ClienteVO;
import VO.PadraoVO;

public class ClienteDAO extends PadraoDAO {
	
	@Override
	public void Cadastrar(PadraoVO pdr) {
		try {
			ClienteVO cliente = (ClienteVO)pdr;
			PrintStream escrever = new PrintStream(new FileOutputStream("Clientes.txt",true));
			String cadastro = "C|"+ cliente.getId()+"|"+ cliente.getNome();
			escrever.println(cadastro);
			System.out.println("\n\nCLIENTE CADASTRADO COM SUCESSO!!!\n\n");
			escrever.close();
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

}
