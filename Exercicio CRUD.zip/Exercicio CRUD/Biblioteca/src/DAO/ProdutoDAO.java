package DAO;

import java.io.FileOutputStream;
import java.io.PrintStream;
import VO.PadraoVO;
import VO.ProdutoVO;

public class ProdutoDAO extends PadraoDAO {
	@Override
	public void Cadastrar(PadraoVO pdr) {
		try {
			ProdutoVO produto = (ProdutoVO)pdr;
			PrintStream escrever = new PrintStream(new FileOutputStream("Produto.txt",true));
			String cadastro = "P|"+ produto.getId()+"|"+ produto.getNome_produto();
			escrever.println(cadastro);
			System.out.println("\n\nPRODUTO CADASTRADO COM SUCESSO!!!\n\n");
			escrever.close();
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
}
