package DAO;

import VO.PadraoVO;

public class PadraoDAO {

	public void Cadastrar(PadraoVO pdr){
		
	}
	
	
}
