import CamadaDeNegocios.Menu;



public class Main {
	public static void main(String[] args) {
		Menu.Menu_Inicio();		
		}
	}

